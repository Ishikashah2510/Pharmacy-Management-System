<!DOCTYPE html>
<html>
<head>
	<title>Manager</title>
	<link rel="stylesheet" type="text/css" href="options.css">
</head>
<body>
<ul>
  <li><a href="cashier_single_detail.php" style="text-decoration: none; color: #F05371">Edit your details</a></li>
  <li><a href="medicine_detail.php" style="text-decoration: none; color: #F05371">View/edit Medicine details</a></li>
  <li><a href="customer_detail.php" style="text-decoration: none; color: #F05371">View/edit customer records</a></li>
  <li><a href="billmake.php" style="text-decoration: none; color: #F05371">Make a bill</a></li>
  <li><a href="Pharmacy_main.php" style="text-decoration: none; color: #F05371">Logout</a></li>
</ul>

</body>
</html>