<!DOCTYPE html>
<html>
<head>
	<title>Manager</title>
	<link rel="stylesheet" type="text/css" href="options.css">
</head>
<body>
<ul>
  <li><a href="new_cust.php" style="text-decoration: none; color: #F05371">New Customer</a></li>
  <li><a href="bill.php" style="text-decoration: none; color: #F05371">Existing Customer</a></li>
</ul>

</body>
</html>