<?php

$connect = mysqli_connect("localhost", "root", "", "pharmacymanagement") or die("connection failed");

?>