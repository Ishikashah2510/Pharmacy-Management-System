This is a project based on Pharmacy Management System, we are keeping records of
employees, medicines, patients, and the doctors who have treated them. We also 
have a bill making system, storing the data not just in the tables but also as 
a text file in the same folder as the webpage. 
The "Employees" table stores the details of the employees, which are of two types,
cashier and manager. The "doctors" table stores the details fo the doctors by whom,
the patients have been treated. The "patients" table stores the details of the
custoers/ patients, who have brought medicine from the pharmacy. The "history" table
is to store the history of patient, by the means, of storing the medicines they bought,
and the date they bought it. The "order" table is to store the data of the orders,
for future reference. The "login" table is to store the login credentials of the 
employees. The "treatment" table is for seeing which patient has been treated by which
doctor. The "Medicine" table is to store the data about the medicine.

When a bill is made, the bill is displayed for a few seconds before redirecting to
making a new bill, and the data is stored. If we are billing for a new patient, 
we take details of the patient and the doctor he was prescribed the medicines by. 
These details are stored in the patient, doctors, treatment table.

Steps to run the program:
1. Install XAMPP.
2. In the XAMPP control, start Apache, MySql.
3. open phpmyadmin on your web browser.
4. create a database "pharmacymanagement".
5. copy inner folder pharmacymanagement in ...\xampp\mysql\data.
6. by localhost open pharmacy_main.php
7. you now have a running pharmacy management system.